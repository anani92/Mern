import React from 'react'

export default function Header() {
  return <div style={{ backgroundColor: ' green', height: '10rem' }}></div>
}
