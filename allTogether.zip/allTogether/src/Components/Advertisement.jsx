import React from 'react'

export default function Advertisement() {
  return (
    <div
      style={{
        backgroundColor: ' teal',
        height: '10rem',
        marginTop: '1rem',
        padding: '5rem',
      }}
    ></div>
  )
}
