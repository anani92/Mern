import React from 'react'

export default function SubContents() {
  return (
    <div style={{ backgroundColor: ' yellow', padding: '6rem' }}>
      hi from content
    </div>
  )
}
