import React from 'react'

export default function Navigation() {
  return (
    <div
      style={{ backgroundColor: ' blue', padding: '10rem', margin: '1rem' }}
    ></div>
  )
}
