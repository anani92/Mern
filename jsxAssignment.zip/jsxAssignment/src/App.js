import './App.css'
import React, { Component } from 'react'

export default class App extends Component {
  render() {
    return (
      <div>
        <h1>Hello Dojo</h1>
        <h2>Things I need to do</h2>
        <ul>
          <li>eat</li>
          <li>sleap</li>
          <li>code</li>
          <li>repeate</li>
        </ul>
        `
      </div>
    )
  }
}
